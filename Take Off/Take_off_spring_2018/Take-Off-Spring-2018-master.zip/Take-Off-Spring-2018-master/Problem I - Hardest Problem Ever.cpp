#include <bits/stdc++.h>
using namespace std;
int main()
{
    printf("Great things take time\n");
    return 0;
}