#include <bits/stdc++.h>
using namespace std;
int main()
{
    int tc;
    scanf("%d",&tc);
    for(int cs = 1; cs <= tc; ++cs){
        int n;
        scanf("%d",&n);
        printf("1");
        for(int i = 1; i <= n; i++)
            printf("0");
        printf("\n");
    }
    return 0;
}
