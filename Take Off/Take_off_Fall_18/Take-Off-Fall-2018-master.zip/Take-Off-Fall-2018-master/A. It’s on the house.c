#include<stdio.h>
int main ()
{
    printf("Rest in peace legend!\n");
    return 0;
}