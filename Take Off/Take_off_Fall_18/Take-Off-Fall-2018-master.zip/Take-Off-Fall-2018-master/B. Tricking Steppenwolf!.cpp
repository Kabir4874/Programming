#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a,b,c;
    scanf("%d %d %d", &a, &b, &c);
    if((a+b+c)==3)
        printf("Become more powerful!\n");
    else
        printf("Loses his power!\n");
    return 0;
}
