#include <stdio.h>
int main(){
    printf("DJ NAJ, I will be the one\n");
    return 0;
}