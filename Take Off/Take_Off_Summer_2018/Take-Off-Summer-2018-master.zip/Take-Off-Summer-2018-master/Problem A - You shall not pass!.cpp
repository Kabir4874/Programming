#include<bits/stdc++.h>
using namespace std;

int main()
{
    printf("I still believe in heroes\n");
    return 0;
} 