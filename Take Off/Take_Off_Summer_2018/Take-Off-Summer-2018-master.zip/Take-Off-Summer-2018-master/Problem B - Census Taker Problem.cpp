#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    scanf("%d", &n);
    printf("%d\n", n/4);
    return 0;
}