class Person{
    private String Name;
    private int Age;
    private String Address;
    public Person(String Name,int Age,String Address){
        this.Name=Name;
        this.Age=Age;
        this.Address=Address;
    }
    public void PrintPersonInfo(){
        System.out.println("Name: "+Name+"\nAge: "+Age+"\nAddress: "+Address);
    }
}
class Teacher extends Person{
    private String TeacherInitial;
    private String EmployeeId;
    Refund refund;
    public Teacher(String Name, int Age, String Address,String TeacherInitial,String EmployeeId) {
        super(Name, Age, Address);
        this.TeacherInitial=TeacherInitial;
        this.EmployeeId=EmployeeId;
        this.refund=new Refund(EmployeeId);
    }
    public void AddDetails(){
        System.out.println("Details Added for Teacher");
    }
    public void MOdifyDetails(){
        System.out.println("Details Modifyed for Teacher");
    }
}
class Student extends Person{
    private String StudentId;
    private String Semester;
    Refund refund;
    public Student(String Name, int Age, String Address,String StudentId,String Semester) {
        super(Name, Age, Address);
        this.StudentId=StudentId;
        this.Semester=Semester;
        this.refund=new Refund(StudentId);
    }
    public void AddDetails(){
        System.out.println("Details Added for Student");
    }
    public void MOdifyDetails(){
        System.out.println("Details Modifyed for Student");
    }
}
interface Function{
    public void SearchTicket();
    public void BookTicket();
    public void CancelTicket();
    public void MakePayment();
    public void FillDetails();
}
class Agent implements Function{
    private int AgentID;
    private String Name;

    @Override
    public void SearchTicket() {
        System.out.println("Searching for ticket...");
    }
    @Override
    public void BookTicket() {
        System.out.println("Booking a ticket...");
    }
    @Override
    public void CancelTicket() { 
        System.out.println("Canceling a ticket...");
    }
    @Override
    public void MakePayment() {  
        System.out.println("Making a payment...");
        System.out.println("Payment complete <3");
    }
    @Override
    public void FillDetails() {  
        System.out.println("Filling details...");
    }
}
class Date{
    public Date(){
        System.out.println("Movie date 21/12/2023");
    }
}
class Time{
    public Time(){
        System.out.println("Movie time 12:30 PM");
    }
}
class Ticket{
    private String TicketId;
    private Date Date;
    private Time Time;
    private String SeatNo;
    private String Source;
    private String Destination;
    public void setSeatNo(String SeatNo){
        this.SeatNo=SeatNo;
    }
    public void setSource(String Source){
        this.Source=Source;
    }
    public void setDestination(String Destination){
        this.Destination=Destination;
    }
    public void getTiketInfo(){
        System.out.println("Tiket Info->"+"\nSeat NO: "+SeatNo+"\nSource: "+Source+"\nDestination: "+Destination);
    }


}
class Refund{
    private String Id;
    private double Amount=100.00;
    public Refund(String Id){
        this.Id=Id;
    }
    public void RefundAmount(){
        System.out.println("\nRefund Id: "+Id+"\nRefund Amount: "+Amount);
    }   
}
public class BookingCounter {
    public static void display(){
        System.out.println("Welcome to the Booking Counter\n");
    }
    public static void main(String[] args) throws Exception {
        BookingCounter.display();

        Student student = new Student("Setab", 21, "uttara-1230", "221-15-5989", "4th");
        student.AddDetails();
        student.PrintPersonInfo();

        Agent agent = new Agent();
        agent.FillDetails();
        agent.SearchTicket();
        agent.BookTicket();
        //agent.CancelTicket();
        agent.MakePayment();

        Ticket ticket = new Ticket();
        ticket.setSeatNo("A12");
        ticket.setSource("City A");
        ticket.setDestination("City B");
        ticket.getTiketInfo();

        Date date = new Date();
        Time time = new Time();
        
        student.refund.RefundAmount();


    }
}
