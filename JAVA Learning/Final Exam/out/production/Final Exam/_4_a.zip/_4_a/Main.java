package _4_a;

public class Main {
    public static void main(String[] args) {
        Apple a= new Apple("Red");
        Banana b= new Banana("Yellow");
        Jackfruit j= new Jackfruit("Green");

        a.display();
        b.display();
        j.display();
    }
}
