package _4_a;

public class Jackfruit extends Fruits{
    public String color;

    public Jackfruit(String color) {
        this.color = color;
    }

    public void display(){
        System.out.println("Jackfruit");
        System.out.println(color);
    }
}
