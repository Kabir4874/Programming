package _4_a;

public abstract class Fruits {
    public abstract void display();
}
